<?php
include("connection/db.php");

echo $email = $_POST['email'];
echo $username = $_POST['Username'];
echo $Password = $_POST['Password'];
echo $first_name = $_POST['first_name'];
echo $last_name = $_POST['last_name'];
echo $admin_type = $_POST['admin_Type'];

$query = mysqli_query($conn, "insert into admin_login(admin_email,admin_pass,admin_username,first_name,last_name,admin_type)values('$email','$Password','$username','$first_name','$last_name','$admin_type')");
var_dump($query);
if ($query) {
    echo "data has been sucessfully inserted";
} else {
    echo "come error";
}
