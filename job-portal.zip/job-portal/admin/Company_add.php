<?php
include("connection/db.php");

echo $Company = $_POST['Company'];
echo $Description = $_POST['Description'];


$query = mysqli_query($conn, "insert into company(company, des)values('$Company','$Description')");
// var_dump($query);
// if ($query) {
//     echo "data has been sucessfully inserted";
// } else {
//     echo "something error,please try agian";
// }
?>