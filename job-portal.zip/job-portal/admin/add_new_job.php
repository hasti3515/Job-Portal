<?php
session_start();
include("connection/db.php");

$login = $_SESSION['email'];
$Job_title = $_POST['job_title'];
$Description = $_POST['Description'];
$country = $_POST['country'];
$state = $_POST['state'];
$city = $_POST['city'];


$query = mysqli_query($conn, "insert into all_jobs(customer_email, job_title,des,country,state,city)values('$login','$Job_title','$Description','$country','$state','$city')");
// var_dump($query);
// if ($query) {
//     echo "data has been sucessfully inserted";
// } else {
//     echo "something error,please try agian";
// }
