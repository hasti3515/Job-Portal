$("document").ready(function () {
  $("#submit").click(function () {
    var email = $("#admin_email");
  });
});
