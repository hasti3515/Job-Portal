<?php
include("connection/db.php");

include("include/header.php");
include("include/sidebar.php");
$id = $_GET['edit'];
$query = mysqli_query($conn, "select * from admin_login where id ='$id'");
while ($row = mysqli_fetch_array($query)) {
    $email = $row['admin_email'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $admin_pass = $row['admin_pass'];
    $admin_username = $row['admin_username'];
    $admin_type = $row['admin_type'];
}
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="admin_dashboard.php">Deshboard</a></li>
            <li class="breadcrumb-item"><a href="Customers.php">Customers</a></li>
            <li class="breadcrumb-item"><a href="#">Update_customer</a></li>
        </ol>
    </nav>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2" style="margin-left: 40%;">Update Customer</h1>

        <div class="btn-toolbar mb-2 mb-md-0">
        </div>
    </div>
    <div style="width: 60%; margin-left:20% ; background-color: #f4f4f4;">
        <div id="msg"></div>
        <form action="" method="post" style="margin: 3%; padding: 3%;" name="customer_form" id="customer_form">
            <div class="form_group">
                <label for="Custmer email">Enter Email </label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo  $email ?>" placeholder="Enter Customer email">
            </div><br>
            <div class="form_group">
                <label for="Custmer Username">Enter Username</label>

                <input type="text" name="Username" id="Username" class="form-control" value="<?php echo  $admin_username ?>" placeholder="Enter Customer Username">
            </div><br>
            <div class="form_group">
                <label for="Custmer Firstname">Enter Password</label>
                <input type="pass" name="Password" id="Password" class="form-control" value="<?php echo  $admin_pass ?>" placeholder="Enter Password">
            </div><br>
            <div class="form_group">
                <label for="Custmer Firstname">Enter First name</label>
                <input type="text" name="first_name" id="first_name" class="form-control" value="<?php echo  $first_name ?>" placeholder="Enter Customer First name">
            </div><br>
            <div class="form_group">
                <label for="Custmer Lastname">Enter Last name</label>
                <input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo  $last_name ?>" placeholder="Enter Customer Last name">
            </div><br>
            <div class="form_group">
                <label for="Admin Type">Admin Type</label>
                <select name="admin_type" class="form-control" value="<?php echo  $admin_type ?>" id="admin_type">
                    <option value="1">Super Admin</option> 
                    <option value="2">Customer Admin</option>
                </select>
            </div><br>
            <input type="hidden" name="id" id="id" value=" <?php echo $_GET['edit']?>">
            <div class="form_group">
                <input type="submit" class="btn btn-success btn-block" placeholder="Update" name="submit" id="submit">
            </div>

        </form>
    </div>
    <!-- if it is deleted and not any efect in output then delete it -->
    <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

</main>


<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')
</script>
<script src="../../assets/js/vendor/popper.min.js"></script>
<script src="../../dist/js/bootstrap.min.js"></script>

<!-- Icons -->
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>

<!-- datatable plugging -->
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.1.5/js/dataTables.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>

</body>

</html>
<?php
include('connection/db.php');
if(isset($_POST['submit'])){
    $id= $_POST['id'];
    $email= $_POST['email'];
    $Username= $_POST['Username'];
    $Password= $_POST['Password'];
    $first_name= $_POST['first_name'];
    $last_name= $_POST['last_name'];
    $admin_type= $_POST['admin_type'];
    $query1 = mysqli_query($conn,"update admin_login set admin_email='$email',admin_username='$Username',admin_pass='$Password',first_name='$first_name',last_name='$last_name',admin_type='$admin_type' where id ='$id'");
    if($query1){
    echo "<script>alert('record has been successfully updated')</script>";

    }else{
    echo "<script>alert('some error reached try agin')</script>";

    }
}
?>