<?php
include("include/header.php");
include("include/sidebar.php");

?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="admin_dashboard.php">Deshboard</a></li>
            <li class="breadcrumb-item"><a href="Job_create.php">All_job_list</a></li>
            <li class="breadcrumb-item"><a href="#">Add_job</a></li>
        </ol>
    </nav>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2" style="margin-left: 40%;">Add Job</h1>

        <div class="btn-toolbar mb-2 mb-md-0">
        </div>
    </div>
    <div style="width: 60%; margin-left:20% ; background-color: #f4f4f4;">
        <div id="msg"></div>
        <form action="" method="post" style="margin: 3%; padding: 3%;" name="job_form" id="job_form">
            <div class="form_group">
                <label for="Custmer email">JOb Title </label>
                <input type="text" name="job_title" id="job_title" class="form-control" placeholder="Enter job title">
            </div><br>
            <div class="form_group">
                <label for="Custmer Username">Description</label>
                <textarea name="Description" id="Description" class="form-control" cols="60" rows="8"></textarea>
            </div><br>
            <div class="form_group">
                <label for="">Country</label>
                <input type="text" name="country" id="countryId" class="form-control" placeholder="Enter country">
            </div>
            <div class="form_group">
                <label for="">State</label>
                <input type="text" name="state" id="stateId" class="form-control" placeholder="Enter state">
            </div>
            <div class="form_group">
                <label for="">City</label>
                <input type="text" name="city" id="cityId" class="form-control" placeholder="Enter city">
            </div><br>
            <div class="form_group">
                <input type="submit" class="btn btn-success btn-block" placeholder="Save" name="submit" id="submit">
            </div>

        </form>
    </div>
    <!-- if it is deleted and not any efect in output then delete it -->
    <canvas class="my-4" id="myChart" width="900" height="380"></canvas>

</main>


<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')
</script>
<script src="../../assets/js/vendor/popper.min.js"></script>
<script src="../../dist/js/bootstrap.min.js"></script>

<!-- Icons -->
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>

<!-- datatable plugging -->
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.1.5/js/dataTables.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script>
    $(document).ready(function() {
        $("#submit").click(function() {
            var Description = $("#Description").val();
            var job_title = $("#job_title").val();
            var CompanyId = $("#CompanyId").val();
            var stateId = $("#stateId").val();
            var cityId = $("#cityId").val();

            if (job_title == '') {
                alert('please enter job title');
                return false;
            }
            if (Description == '') {
                alert('please enter Description');
                return false;
            }
            if (CompanyId == '') {
                alert('please enter company ');
                return false;
            }
            if (stateId == '') {
                alert('please enter state ');
                return false;
            }
            if (cityId == '') {
                alert('please enter city');
                return false;
            }

            var data = $("#job_form").serialize();
            $.ajax({
                type: "POST",
                url: "add_new_job.php",
                data: data,
                success: function(data) {
                    $("#msg").html(data);
                }
            });
        });
    });
</script>
</body>

</html>